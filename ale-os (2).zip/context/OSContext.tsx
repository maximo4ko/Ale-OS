import React, { createContext, useContext, useState, useEffect, ReactNode, useRef } from 'react';
import { AppId, OSView, Notification, IconConfig, MusicState, Song } from '../types';
import { WALLPAPERS } from '../constants';

// Playlist with User's requested Phonk/Funk titles
// COVERS: Extracted from YouTube.
// AUDIO: Direct .m4a links provided by user.
const TRACKS: Song[] = [
  {
    title: "MONTAGEM REBOLA",
    artist: "DJ Mandy / RXDX VILAO",
    url: "https://cdn.discordapp.com/attachments/1350380777774256138/1455700976961982546/5mnukIQFwx8LXVNLRAMTtXR4-ahomuY.m4a?ex=6955aeae&is=69545d2e&hm=d9f62cf59735f8842fb495237e5a54a1bf293448de4f0512941000c10ebed76b&", 
    cover: "https://img.youtube.com/vi/xcNLg8Thkh0/hqdefault.jpg" 
  },
  {
    title: "sem nada",
    artist: "Phonk Edition",
    url: "https://cdn.discordapp.com/attachments/1350380777774256138/1455700879226437843/fKYZJMON5IOttt8suRkj9LuXLWhyjl8.m4a?ex=6955ae97&is=69545d17&hm=93b0a3cf4b06784fbd015aa52f98c9a309ad87a704e9302d86b162947773605a&", 
    // Updated to the specific YouTube thumbnail requested by the user
    cover: "https://img.youtube.com/vi/7HUWFDfj97Y/hqdefault.jpg"
  },
  {
    title: "Montagem - Volte Sempre",
    artist: "Slowed + Reverb",
    url: "https://cdn.discordapp.com/attachments/1350380777774256138/1455701241215848448/kZUdYxzSW3CW1aJRNI7FBv96IljoKkg.m4a?ex=6955aeed&is=69545d6d&hm=9359b165fd00d92296433338a27b1cc1a40896796cd3854572319490a6a50836&",
    cover: "https://img.youtube.com/vi/Bv96IljoKkg/hqdefault.jpg" 
  },
  {
    title: "BAD HAPPENING FUNK",
    artist: "Brazilian Phonk",
    url: "https://cdn.discordapp.com/attachments/1350380777774256138/1455700524342050897/xWpEls7Oqb4mzWTin65Bz15uWVY-DfE.m4a?ex=6955ae42&is=69545cc2&hm=6049f7147e6f1ce82d2465e3ba3472dcb78776de7e7607474dabf3a0b65c5e8c&",
    cover: "https://img.youtube.com/vi/z15uWVY-DfE/hqdefault.jpg" 
  }
];

interface StopwatchState {
  isRunning: boolean;
  startTime: number;
  accumulatedTime: number;
}

interface OSContextType {
  view: OSView;
  activeApp: AppId | null;
  wallpaper: string;
  brightness: number;
  volume: number;
  wifiEnabled: boolean;
  bluetoothEnabled: boolean;
  notifications: Notification[];
  currentTime: Date;
  isControlCenterOpen: boolean;
  stopwatch: StopwatchState;
  
  // Customization
  iconConfig: IconConfig;
  setIconConfig: (config: Partial<IconConfig>) => void;
  
  // Music
  musicState: MusicState;
  playMusic: () => void;
  pauseMusic: () => void;
  nextTrack: () => void;
  prevTrack: () => void;

  // Actions
  unlock: () => void;
  lock: () => void;
  wake: () => void;
  toggleSleep: () => void;
  openApp: (appId: AppId) => void;
  closeApp: () => void;
  toggleControlCenter: () => void;
  setWallpaper: (url: string) => void;
  setBrightness: (val: number) => void;
  setVolume: (val: number) => void;
  toggleWifi: () => void;
  toggleBluetooth: () => void;
  addNotification: (n: Notification) => void;
  clearNotification: (id: string) => void;
  
  // Stopwatch Actions
  toggleStopwatch: () => void;
  resetStopwatch: () => void;
}

const OSContext = createContext<OSContextType | undefined>(undefined);

export const OSProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [view, setView] = useState<OSView>(OSView.LOCK_SCREEN);
  const [activeApp, setActiveApp] = useState<AppId | null>(null);
  const [wallpaper, setWallpaper] = useState(WALLPAPERS[0]);
  const [brightness, setBrightness] = useState(100);
  const [volume, setVolume] = useState(75);
  const [wifiEnabled, setWifiEnabled] = useState(true);
  const [bluetoothEnabled, setBluetoothEnabled] = useState(true);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isControlCenterOpen, setIsControlCenterOpen] = useState(false);

  // Icon Customization Defaults
  const [iconConfig, setIconConfigState] = useState<IconConfig>({
    size: 60,
    style: 'standard',
    showLabels: true
  });

  const setIconConfig = (newConfig: Partial<IconConfig>) => {
    setIconConfigState(prev => ({ ...prev, ...newConfig }));
  };

  // Stopwatch State
  const [stopwatch, setStopwatch] = useState<StopwatchState>({ isRunning: false, startTime: 0, accumulatedTime: 0 });
  const stopwatchIntervalRef = useRef<number | null>(null);

  // Music State
  const [musicState, setMusicState] = useState<MusicState>({
    isPlaying: false,
    currentTrackIndex: 0,
    trackList: TRACKS
  });
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize Audio
  useEffect(() => {
    // Force reset audio element when TRACKS change to ensure clean state
    if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
    }
    audioRef.current = new Audio(TRACKS[0].url);
    audioRef.current.loop = true;
    
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []); // Run once on mount

  // Sync Audio with State
  useEffect(() => {
    if (!audioRef.current) return;
    
    // Update src if track changed
    const currentUrl = TRACKS[musicState.currentTrackIndex].url;
    
    // Check if the source URL has actually changed to avoid reloading on every render
    // Note: audio.src resolves to absolute path, so we compare carefully or just check simple equality
    if (audioRef.current.src !== currentUrl) {
      audioRef.current.src = currentUrl;
      audioRef.current.load(); // Load new source
      if (musicState.isPlaying) {
          audioRef.current.play().catch(e => console.log("Audio play failed (interaction needed first):", e));
      }
    } else {
        // Just play/pause toggle
        if (musicState.isPlaying) {
            audioRef.current.play().catch(e => console.log("Audio play failed:", e));
        } else {
            audioRef.current.pause();
        }
    }
  }, [musicState.isPlaying, musicState.currentTrackIndex]);

  // Handle Volume Change
  useEffect(() => {
      if(audioRef.current) {
          audioRef.current.volume = volume / 100;
      }
  }, [volume]);

  const playMusic = () => setMusicState(prev => ({ ...prev, isPlaying: true }));
  const pauseMusic = () => setMusicState(prev => ({ ...prev, isPlaying: false }));
  
  const nextTrack = () => {
    setMusicState(prev => {
        const next = (prev.currentTrackIndex + 1) % prev.trackList.length;
        return { ...prev, currentTrackIndex: next };
    });
  };

  const prevTrack = () => {
    setMusicState(prev => {
        const next = prev.currentTrackIndex === 0 ? prev.trackList.length - 1 : prev.currentTrackIndex - 1;
        return { ...prev, currentTrackIndex: next };
    });
  };

  // Clock tick
  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  // Stopwatch Logic
  useEffect(() => {
    if (stopwatch.isRunning) {
      stopwatchIntervalRef.current = window.setInterval(() => {
        // Force update to trigger re-renders for UI
        setStopwatch(prev => ({ ...prev }));
      }, 10) as unknown as number;
    } else {
      if (stopwatchIntervalRef.current) clearInterval(stopwatchIntervalRef.current);
    }
    return () => {
      if (stopwatchIntervalRef.current) clearInterval(stopwatchIntervalRef.current);
    };
  }, [stopwatch.isRunning]);

  const toggleStopwatch = () => {
    setStopwatch(prev => {
      if (prev.isRunning) {
        // Pause
        return {
          ...prev,
          isRunning: false,
          accumulatedTime: prev.accumulatedTime + (Date.now() - prev.startTime),
          startTime: 0
        };
      } else {
        // Start
        return {
          ...prev,
          isRunning: true,
          startTime: Date.now(),
        };
      }
    });
  };

  const resetStopwatch = () => {
    setStopwatch({ isRunning: false, startTime: 0, accumulatedTime: 0 });
  };

  const unlock = () => {
    setView(OSView.HOME_SCREEN);
    setIsControlCenterOpen(false);
  };

  const lock = () => {
    setView(OSView.LOCK_SCREEN);
    setActiveApp(null);
    setIsControlCenterOpen(false);
  };

  const wake = () => {
    if (view === OSView.ALWAYS_ON) {
      setView(OSView.LOCK_SCREEN);
    }
  };

  const toggleSleep = () => {
    setView(prev => {
      if (prev === OSView.ALWAYS_ON) return OSView.LOCK_SCREEN;
      return OSView.ALWAYS_ON;
    });
    setIsControlCenterOpen(false);
    setActiveApp(null);
  };

  const openApp = (appId: AppId) => {
    setActiveApp(appId);
    setView(OSView.APP_OPEN);
    setIsControlCenterOpen(false);
  };

  const closeApp = () => {
    setActiveApp(null);
    setView(OSView.HOME_SCREEN);
  };

  const toggleControlCenter = () => setIsControlCenterOpen(prev => !prev);

  const addNotification = (n: Notification) => setNotifications(prev => [n, ...prev]);
  const clearNotification = (id: string) => setNotifications(prev => prev.filter(n => n.id !== id));
  
  const toggleWifi = () => setWifiEnabled(prev => !prev);
  const toggleBluetooth = () => setBluetoothEnabled(prev => !prev);

  return (
    <OSContext.Provider value={{
      view, activeApp, wallpaper, brightness, volume, wifiEnabled, bluetoothEnabled, notifications, currentTime, isControlCenterOpen, stopwatch,
      iconConfig, setIconConfig,
      musicState, playMusic, pauseMusic, nextTrack, prevTrack,
      unlock, lock, wake, toggleSleep, openApp, closeApp, toggleControlCenter, setWallpaper, setBrightness, setVolume, toggleWifi, toggleBluetooth, addNotification, clearNotification,
      toggleStopwatch, resetStopwatch
    }}>
      {children}
    </OSContext.Provider>
  );
};

export const useOS = () => {
  const context = useContext(OSContext);
  if (!context) throw new Error("useOS must be used within OSProvider");
  return context;
};
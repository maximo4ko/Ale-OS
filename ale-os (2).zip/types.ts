import { ReactNode } from "react";

export enum AppId {
  PHONE = 'phone',
  MESSAGES = 'messages',
  BROWSER = 'browser',
  SETTINGS = 'settings',
  CALCULATOR = 'calculator',
  CLOCK = 'clock',
  CAMERA = 'camera',
  GALLERY = 'gallery',
  CONTACTS = 'contacts',
  WEATHER = 'weather',
  MUSIC = 'music',
}

export interface AppConfig {
  id: AppId;
  name: string;
  icon: ReactNode;
  color: string;
  component: ReactNode;
}

export enum OSView {
  ALWAYS_ON = 'ALWAYS_ON',
  LOCK_SCREEN = 'LOCK_SCREEN',
  HOME_SCREEN = 'HOME_SCREEN',
  APP_OPEN = 'APP_OPEN',
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  appId: AppId;
  timestamp: Date;
}

export type IconStyle = 'standard' | 'dark';

export interface IconConfig {
  size: number; // px value, e.g., 60
  style: IconStyle;
  showLabels: boolean;
}

export interface Song {
  title: string;
  artist: string;
  url: string; // URL to audio file
  cover: string; // URL to cover art
}

export interface MusicState {
  isPlaying: boolean;
  currentTrackIndex: number;
  trackList: Song[];
}
import React from 'react';
import { useOS } from '../../context/OSContext';
import { Wifi, Bluetooth, Sun, Volume2, Flashlight, Plane, Moon, RotateCw, Signal, Play, Pause, SkipForward } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ControlCenter: React.FC = () => {
  const { 
    isControlCenterOpen, toggleControlCenter, 
    wifiEnabled, toggleWifi, 
    bluetoothEnabled, toggleBluetooth,
    brightness, setBrightness,
    volume, setVolume,
    musicState, playMusic, pauseMusic, nextTrack
  } = useOS();

  const currentSong = musicState.trackList[musicState.currentTrackIndex];

  return (
    <AnimatePresence>
      {isControlCenterOpen && (
        <>
          {/* Backdrop */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={toggleControlCenter}
            className="absolute inset-0 bg-black/30 backdrop-blur-sm z-40"
          />
          
          {/* Panel */}
          <motion.div 
            initial={{ y: -500, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -500, opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="absolute top-2 left-2 right-2 bg-gray-900/90 backdrop-blur-xl rounded-3xl p-4 z-50 text-white shadow-2xl border border-white/10"
          >
            <div className="grid grid-cols-2 gap-3 mb-4">
              {/* Connectivity Group */}
              <div className="bg-gray-800/50 rounded-2xl p-3 grid grid-cols-2 gap-2">
                <button 
                  onClick={toggleWifi}
                  className={`aspect-square rounded-full flex items-center justify-center transition-all ${wifiEnabled ? 'bg-blue-500 text-white' : 'bg-gray-700/50 text-gray-400'}`}
                >
                  <Wifi size={20} />
                </button>
                <button 
                  onClick={toggleBluetooth}
                  className={`aspect-square rounded-full flex items-center justify-center transition-all ${bluetoothEnabled ? 'bg-blue-500 text-white' : 'bg-gray-700/50 text-gray-400'}`}
                >
                  <Bluetooth size={20} />
                </button>
                <button className="aspect-square rounded-full flex items-center justify-center bg-gray-700/50 text-gray-400">
                  <Plane size={20} />
                </button>
                <button className="aspect-square rounded-full flex items-center justify-center bg-green-500 text-white">
                  <Signal size={20} />
                </button>
              </div>

              {/* Media Controls / Other */}
              <div className="bg-gray-800/50 rounded-2xl p-3 flex flex-col justify-between overflow-hidden relative">
                 {musicState.isPlaying && (
                     <div className="absolute inset-0 opacity-20">
                         <img src={currentSong.cover} className="w-full h-full object-cover blur-sm" alt="bg" />
                     </div>
                 )}
                
                <div className="text-xs text-gray-400 relative z-10">Now Playing</div>
                <div className="relative z-10">
                    <div className="text-sm font-medium truncate">{currentSong.title}</div>
                    <div className="text-[10px] text-gray-400 truncate">{currentSong.artist}</div>
                </div>
                
                <div className="flex justify-between items-center mt-2 relative z-10">
                   <button onClick={musicState.isPlaying ? pauseMusic : playMusic}>
                       {musicState.isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
                   </button>
                   <button onClick={nextTrack}>
                       <SkipForward size={20} fill="currentColor" />
                   </button>
                </div>
              </div>
            </div>

            {/* Sliders */}
            <div className="bg-gray-800/50 rounded-2xl p-3 mb-4 space-y-4">
              <div className="flex items-center gap-3">
                <Sun size={20} className="text-gray-400" />
                <input 
                  type="range" 
                  min="0" max="100" 
                  value={brightness} 
                  onChange={(e) => setBrightness(Number(e.target.value))}
                  className="w-full h-8 rounded-full appearance-none bg-gray-700 overflow-hidden [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-0 [&::-webkit-slider-thumb]:h-0"
                  style={{
                    backgroundImage: `linear-gradient(90deg, white ${brightness}%, transparent ${brightness}%)`
                  }}
                />
              </div>
              <div className="flex items-center gap-3">
                <Volume2 size={20} className="text-gray-400" />
                <input 
                  type="range" 
                  min="0" max="100" 
                  value={volume} 
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="w-full h-8 rounded-full appearance-none bg-gray-700 overflow-hidden [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-0 [&::-webkit-slider-thumb]:h-0"
                  style={{
                    backgroundImage: `linear-gradient(90deg, white ${volume}%, transparent ${volume}%)`
                  }}
                />
              </div>
            </div>

            {/* Toggles Row */}
            <div className="grid grid-cols-4 gap-3">
               <button className="aspect-square bg-gray-800/50 rounded-2xl flex items-center justify-center active:bg-white active:text-black transition-colors">
                 <Flashlight size={24} />
               </button>
               <button className="aspect-square bg-gray-800/50 rounded-2xl flex items-center justify-center active:bg-white active:text-black transition-colors">
                 <RotateCw size={24} />
               </button>
               <button className="aspect-square bg-gray-800/50 rounded-2xl flex items-center justify-center active:bg-white active:text-black transition-colors">
                 <Moon size={24} />
               </button>
               <button className="aspect-square bg-gray-800/50 rounded-2xl flex items-center justify-center active:bg-white active:text-black transition-colors">
                 <div className="font-mono text-xs font-bold">REC</div>
               </button>
            </div>
            
            <div className="w-12 h-1 bg-gray-600 rounded-full mx-auto mt-4" />
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default ControlCenter;